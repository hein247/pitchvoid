
  # PitchVoid Animation

  This is a code bundle for PitchVoid Animation. The original project is available at https://www.figma.com/design/XKMm9g0qiGCB5ixB0ZnA5M/PitchVoid-Animation.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  