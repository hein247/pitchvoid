import { createBrowserRouter, Outlet } from "react-router";
import { HowItWorks } from "./components/HowItWorks";

function Root() {
  return (
    <div className="w-full min-h-screen bg-zinc-950 text-white font-sans flex items-center justify-center">
      <Outlet />
    </div>
  );
}

function Home() {
  return <HowItWorks />;
}

function Dashboard() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen text-center px-4">
      <h1 className="text-3xl md:text-5xl font-medium text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500 mb-6">
        Welcome to your clear head.
      </h1>
      <p className="text-zinc-400 max-w-md mx-auto">
        Your dashboard is ready. Time to turn that mess into something beautiful.
      </p>
    </div>
  );
}

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Home },
      { path: "dashboard", Component: Dashboard },
    ],
  },
]);
